@echo off
REM Makes the bridge start automatically (hidden) every time you log in to Windows.
set SCRIPT=%~dp0run-hidden.vbs
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\ChutznikBridge.lnk');$s.TargetPath='%SCRIPT%';$s.Save()"
echo.
echo  Done! The Chutznik bridge will now start by itself whenever this computer logs in.
echo  It runs invisibly in the background. To stop it: run uninstall-autostart.bat,
echo  then open Task Manager and end any "Microsoft Windows Based Script Host" task.
echo.
pause
