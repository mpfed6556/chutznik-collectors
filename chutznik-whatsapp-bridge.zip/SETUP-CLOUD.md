# Chutznik WhatsApp Bridge — Cloud Setup (~€4/month, runs 24/7)

## What you get
The bridge runs on a small rented server instead of your computer:
always on, auto-restarts, your PC and even your phone can be off.

## Step 0 — Put the bridge where the server can download it (2 min)
1. Go to github.com → your PUBLIC repo **chutznik-collectors**
2. Add file → Upload files → drag **chutznik-whatsapp-bridge.zip** in → Commit
   (the zip contains no passwords — the key is added on the server in step 3)

## Step 1 — Rent the server (5 min, ~€3.99/month)
1. Sign up at **hetzner.com** → Cloud (or DigitalOcean.com if you prefer, ~$6-8/mo — same steps)
2. New Project → **Add Server**:
   - Location: **Falkenstein or Helsinki** (any)
   - Image: **Ubuntu 24.04**
   - Type: the cheapest **shared vCPU x86** with **4 GB RAM** (CX22/CPX21 class)
     (4 GB matters: WhatsApp's engine + image-reading are hungry)
   - Leave everything else default → Create
3. On the server's page click **">_ Console"** (top right) — a black terminal
   opens in your browser. Log in as `root` with the password Hetzner emailed
   (it forces you to set a new one — save it!).

## Step 2 — Install everything (one paste, ~5 min)
Copy this WHOLE block, paste into the console (right-click → paste), press Enter:

```
apt-get update && apt-get install -y curl unzip chromium-browser fonts-liberation libnss3 libatk-bridge2.0-0 libgtk-3-0 libgbm1 libasound2t64 && curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs && mkdir -p /opt && cd /opt && curl -L -o bridge.zip https://raw.githubusercontent.com/mpfed6556/chutznik-collectors/main/chutznik-whatsapp-bridge.zip && unzip -o bridge.zip -d chutznik-bridge && cd chutznik-bridge && npm install && echo "PUPPETEER_EXECUTABLE_PATH=$(command -v chromium-browser || command -v chromium)" >> .env.example && cp -n .env.example .env && npm install -g pm2 && echo DONE — now run: npm start
```

Wait for **DONE**. (Red npm warnings are normal.)

## Step 3 — Link WhatsApp (one time)
```
cd /opt/chutznik-bridge && npm start
```
A QR code appears IN the console → phone → WhatsApp → Settings →
**Linked devices → Link a device** → scan the screen.
Wait until you see: `Connected. Watching ALL group chats` and the
catch-up lines. Then press **Ctrl+C** to stop it (next step makes it permanent).

## Step 4 — Make it run forever (one paste)
```
cd /opt/chutznik-bridge && pm2 start bridge.js --name chutznik-bridge --max-memory-restart 1500M && pm2 save && pm2 startup | tail -1 | bash && pm2 save
```
Done. It now runs 24/7, restarts itself if it crashes, and starts
automatically if the server ever reboots.

## Daily life
- **See what it's doing**:  `pm2 logs chutznik-bridge`   (Ctrl+C exits the view, bridge keeps running)
- **Restart it**:           `pm2 restart chutznik-bridge`
- **Stop it**:              `pm2 stop chutznik-bridge`
- Close the console window anytime — nothing stops.
- Your phone can be offline; WhatsApp keeps the link alive (reconnect the
  phone to internet at least once every ~2 weeks).

## Notes
- Cost: Hetzner ~€3.99–5.5/mo depending on type. Cancel anytime.
- If `npm start` says "No browser found": run
  `echo "PUPPETEER_EXECUTABLE_PATH=$(command -v chromium-browser || command -v chromium)" >> .env` and try again.
- This reads your own account's groups, read-only. Keep volumes reasonable —
  automation on personal WhatsApp is officially a gray zone.
