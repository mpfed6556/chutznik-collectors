# Chutznik WhatsApp Bridge v2 — setup (10 minutes, once)

## What it does
Watches ALL the WhatsApp groups on this account and turns real content into
draft posts in YOUR review queue on chutznik.org (amber rows — nothing goes
public until you press ✓ Publish):
- Rentals & business ads → ALWAYS forwarded, with photos and contact numbers
- A question + the answers people gave → ONE combined post (all numbers together)
- Photos are uploaded AND read (OCR) — text inside images goes into the post
- Chit-chat, thank-yous, mazel-tovs → skipped

## Setup
1. Make sure Node.js is installed (nodejs.org → LTS → install)
2. Put this folder somewhere permanent, e.g. Documents\chutznik\whatsapp-bridge
3. Copy `.env.example` to a file named exactly `.env` — open it in Notepad and
   make sure INGEST_KEY matches the key in Vercel (same one as the collectors)
4. Open this folder in a terminal (in File Explorer: type `cmd` in the address bar)
5. Run:  `npm install`   (first time only; takes a few minutes; warnings are fine)
   If it mentions blocked install scripts, also run: `npm approve-scripts --allow-scripts-pending` and approve puppeteer + tesseract.js.
6. Run:  `npm start`  → scan the QR with WhatsApp (Settings → Linked devices)
7. You'll see "Connected. Watching ALL group chats". Leave it running.

## Make it start by itself (recommended)
Double-click **install-autostart.bat** once. From now on the bridge starts
invisibly every time the computer logs in, and restarts itself if it crashes.
(Undo any time with uninstall-autostart.bat.)

## Questions you asked
**Can it run from my phone?** Not by itself — WhatsApp only lets a *linked
computer* read chats this way. BUT: thanks to WhatsApp multi-device, once
linked, the bridge keeps working even when your phone is off or elsewhere
(for up to ~2 weeks without the phone coming online). The computer must be on;
if you ever want it running 24/7 without your computer, it can be moved to a
tiny cloud server (~$5/month) — ask Claude when you're ready.

**Which chats?** All groups. To skip some, add to .env:
`EXCLUDE_CHATS=Family,Besties`
