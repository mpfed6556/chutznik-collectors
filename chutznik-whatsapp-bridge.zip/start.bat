@echo off
title Chutznik WhatsApp Bridge
cd /d "%~dp0"
:loop
node bridge.js
echo Bridge stopped — restarting in 15 seconds... (close this window to stop)
timeout /t 15 /nobreak >nul
goto loop
