@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ChutznikBridge.lnk" 2>nul
echo Autostart removed. (An already-running bridge keeps running until you close it or restart.)
pause
